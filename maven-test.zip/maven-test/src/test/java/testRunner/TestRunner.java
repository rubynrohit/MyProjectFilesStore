package testRunner;

import cucumber.api.java.Before;
import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith (Cucumber.class)
@CucumberOptions(features="Features" ,glue={"testStepCode"}, tags = {"@ExchangeRate"})
public class TestRunner {

}
