package testStepCode;

import cucumber.api.DataTable;
import io.restassured.RestAssured;
import org.json.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.http.HttpResponse;
import java.util.List;


public class StepDefinitions {
	
	WebDriver driver;
	CommonMethods com =new CommonMethods();
	private static HttpResponse retreivedResponse=null;
	 static JSONObject jsonData;
	
	@Given("^rates API endpoint for foreign exchange rates$")
	public void retrieveApiEndpoint() throws Throwable {
		try {
			RestAssured.baseURI = " https://api.ratesapi.io/api";
		}
		catch(Exception e){
			System.out.println("Failed to set baseURI endpoint");
		}
	}

	@When("^the API is available$")
	public void checkApiAvailable(DataTable data) throws Throwable {
		try {
			List<List<String>> endpoint = data.raw();
			String endpointuri = endpoint.get(1).get(0);
			Assert.assertTrue(!endpointuri.isEmpty());
			if (!endpointuri.isEmpty())
				System.out.println("API endpoint is available to test");
			else
				System.out.println("API endpoint is unvailable to test");
			retreivedResponse=com.makeGetRequest(endpointuri);
			Assert.assertTrue(!retreivedResponse.equals(null));


		}
		catch(Exception e){
			System.out.println("Could not test API availability");
			//can handle exception here
		}

	}

	@Then("^validate if API is responding correct status code$")
	public void validateStatusCode(DataTable data) throws Throwable {
		try {
			List<List<String>> endpoint = data.raw();

			int statusCode = retreivedResponse.getStatusLine().getStatusCode();
			if (statusCode != 200) {
				System.out.println("Failure , received status code :"+statusCode);
				throw new RuntimeException("Failed with HTTP error code : " + statusCode);
			}
			else
				System.out.println("Received success code :"+statusCode);
			Assert.assertEquals(statusCode,200);
		}
		catch(Exception e){
			System.out.println("Could not validate API response code!");
		}
	}

	@Then("^validate if API is responding with valid response$")
	public void validateResponse(DataTable data)
	{
		try{
			String mxn_Data="";
			if(!jsonData.isEmpty()){
				//retrieve json data values
				mxn_Data=jsonData.getJSONObject("rates").get("MXN").toString();
			}
			else
				Assert.assertFalse(jsonData.isEmpty());

			System.out.println(mxn_Data);


		}
		catch(Exception e){
			System.out.println(e.getMessage());
			System.out.println("Could not validate API response!");
		}
	}


}
