package testStepCode;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;


import java.io.IOException;

import static io.restassured.RestAssured.given;

public class CommonMethods {

    public void getRequest(String endpoint) {
        try {
            RestAssured.baseURI = " https://api.ratesapi.io/api";
            Response response = given()
                    .when()
                    .get(endpoint)
                    .then()
                    .extract().response();
            //System.out.println("Status code received as:"+response.statusCode());

            Assertions.assertEquals(200, response.statusCode());
        } catch (Exception e) {
            //handle exception
        }
    }

    public  HttpResponse getRESTAPI(String url) throws Exception {
        DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpResponse response;
        try {
            //Define a HttpGet request; You can choose between HttpPost, HttpDelete or HttpPut also.
            //Choice depends on type of method you will be invoking.
            HttpGet getRequest = new HttpGet(url);

            //Set the API media type in http accept header
            getRequest.addHeader("accept", "application/xml");

            //Send the request; It will immediately return the response in HttpResponse object
             response = httpClient.execute(getRequest);

        } finally {
            //Important: Close the connect
            httpClient.getConnectionManager().shutdown();
        }
        return response;
    }

    public CloseableHttpResponse makeGetRequest(String url) throws IOException {

        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse response;

        try {

            HttpGet request = new HttpGet(url);

             response = httpClient.execute(request);

            try {

                // Get HttpResponse Status
                System.out.println(response.getProtocolVersion());              // HTTP/1.1
                System.out.println(response.getStatusLine().getStatusCode());   // 200
                System.out.println(response.getStatusLine().getReasonPhrase()); // OK
                System.out.println(response.getStatusLine().toString());        // HTTP/1.1 200 OK

                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    // return it as a String
                    String result = EntityUtils.toString(entity);
                    StepDefinitions.jsonData= new JSONObject(result);
                    System.out.println(result);
                }

            } finally {
                response.close();
            }
        } finally {
            httpClient.close();
        }
return response;
    }

}

